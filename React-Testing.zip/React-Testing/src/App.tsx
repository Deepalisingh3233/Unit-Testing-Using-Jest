import { useState } from 'react';
import './App.css';
import InputEcho from './InputEcho';

const user = {
  name: 'Ankita Bajpai'
};

function handleClick() {
  alert("Hello, I am " + user.name);
}

function MyButton() {
  return (
    <button className="btn" onClick={handleClick}>
      Click Me!
    </button>
  );
}

export default function App() {

  const [count, setCount] = useState(0)

  return (
    <>
    <div className="main">
      <h1>{user.name}</h1>
      <img
        className="avatar"
        src="https://i.imgur.com/yXOvdOSs.jpg"
        alt={`Photo of ${user.name}`}
        style={{
          width: 90,
          height: 90,
          borderRadius: '50%',
        }}
      />

      {/* ✅ Re-enable the MyButton rendering */}
      <div>
        <MyButton />
      </div>

      <div>
        <h2>Type Something:</h2>
        {/* <InputEcho/> */}
      </div>
    </div>
    </>
  );
}
